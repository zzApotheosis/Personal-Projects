$ go run functions.go 
1+2 = 3
1+2+3 = 6

# There are several other features to Go functions. One is
# multiple return values, which we'll look at next.
