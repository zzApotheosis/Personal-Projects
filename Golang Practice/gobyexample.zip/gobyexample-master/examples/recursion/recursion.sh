$ go run recursion.go 
5040
