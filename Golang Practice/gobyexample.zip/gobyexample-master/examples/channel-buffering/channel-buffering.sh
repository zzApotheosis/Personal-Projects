$ go run channel-buffering.go 
buffered
channel
