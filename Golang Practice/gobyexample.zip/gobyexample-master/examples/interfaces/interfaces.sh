$ go run interfaces.go
{3 4}
12
14
{5}
78.53981633974483
31.41592653589793

# To learn more about Go's interfaces, check out this
# [great blog post](http://jordanorelli.tumblr.com/post/32665860244/how-to-use-interfaces-in-go).
