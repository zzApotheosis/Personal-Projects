$ go run variadic-functions.go 
[1 2] 3
[1 2 3] 6
[1 2 3 4] 10

# Another key aspect of functions in Go is their ability
# to form closures, which we'll look at next.
