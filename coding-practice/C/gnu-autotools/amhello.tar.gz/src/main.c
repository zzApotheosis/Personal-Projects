#include <config.h>
#include <stdio.h>

int main(int argc, char ** argv) {
    puts("Hello World!");
    puts("This is " PACKAGE_STRING ".");
    return(0);
}
